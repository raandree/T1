# SCComplianceTag

## Description

This resource configures a Compliance Tag in Security and Compliance.

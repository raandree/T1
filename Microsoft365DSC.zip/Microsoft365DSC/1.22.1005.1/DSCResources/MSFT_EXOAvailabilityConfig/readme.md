# EXOAvailabilityConfig

## Description

This resource configures the Availability Config in Exchange Online.

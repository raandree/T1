# EXOAuthenticationPolicy

## Description

This resource configures Authentication Policies in Exchange Online.

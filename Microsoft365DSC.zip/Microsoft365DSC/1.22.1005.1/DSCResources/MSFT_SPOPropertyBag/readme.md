# SPOPropertyBag

## Description

Configures a value in a site's property bag.

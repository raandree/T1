# EXOSafeAttachmentPolicy

## Description

This resource configures the settings of the Safe Attachments policies
in your cloud-based organization.

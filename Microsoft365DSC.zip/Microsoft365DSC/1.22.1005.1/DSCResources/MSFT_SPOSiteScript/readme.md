# SPOSiteScript

## Description

This resource allows users to manage JSON files that specify an ordered list of actions to run when creating the new sites.

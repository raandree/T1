
# IntuneDeviceEnrollmentPlatformRestriction

## Description

This resource configures the Intune device platform enrollment restrictions.

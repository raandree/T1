# AADUser

## Description

This resource allows users to create Azure AD Users and assign them licenses.

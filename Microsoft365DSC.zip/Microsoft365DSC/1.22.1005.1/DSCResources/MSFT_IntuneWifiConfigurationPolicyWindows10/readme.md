
# IntuneWifiConfigurationPolicyWindows10

## Description

This resource configures an Intune Wifi Configuration Policy for Windows10 Device.

# EXOInboundConnector

## Description

This resource configures an Inbound connector in your cloud-based organization.

# EXOAntiPhishPolicy

## Description

This resource configures an Anti-Phish Policy in Exchange Online.
Reference: https://docs.microsoft.com/en-us/powershell/module/exchange/advanced-threat-protection/new-antiphishpolicy?view=exchange-ps

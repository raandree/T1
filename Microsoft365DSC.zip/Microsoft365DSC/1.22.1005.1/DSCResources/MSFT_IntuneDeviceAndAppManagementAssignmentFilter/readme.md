
# IntuneDeviceAndAppManagementAssignmentFilter

## Description

This resource represents the properties of the Intune Assignment Filter.
For more information: https://docs.microsoft.com/en-us/graph/api/resources/intune-policyset-deviceandappmanagementassignmentfilter?view=graph-rest-beta


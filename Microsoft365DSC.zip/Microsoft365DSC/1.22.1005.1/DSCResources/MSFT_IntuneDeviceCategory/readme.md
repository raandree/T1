
# IntuneDeviceCategory

## Description

This resource configures the Intune device categories.

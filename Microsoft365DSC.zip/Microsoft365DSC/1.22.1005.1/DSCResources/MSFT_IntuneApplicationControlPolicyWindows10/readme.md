
# IntuneApplicationControlPolicyWindows10

## Description

This resource configures a Intune Endpoint Protection Application Control policy for an Windows 10 Device.

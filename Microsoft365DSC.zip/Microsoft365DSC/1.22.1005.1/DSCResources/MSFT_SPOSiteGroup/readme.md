
# SPOSiteGroup

## Description

Configure groups for a SharePoint Online site.

# IntuneDeviceConfigurationPolicyAndroidOpenSourceProject

## Description

This resource configures an Intune device configuration profile for an Android Open Source Project Device.

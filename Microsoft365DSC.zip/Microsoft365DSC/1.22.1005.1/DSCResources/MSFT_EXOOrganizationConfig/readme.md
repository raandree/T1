# EXOOrganizationConfig

## Description

This resource configures the Exchange Online organization-wide
settings.

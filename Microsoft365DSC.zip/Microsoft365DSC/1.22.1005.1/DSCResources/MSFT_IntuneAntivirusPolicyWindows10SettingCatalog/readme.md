
# IntuneAntivirusPolicyWindows10SettingCatalog

## Description

This resource configures an Intune Endpoint Protection Antivirus policy for a Windows 10 Device.
This policy setting enables the management of Microsoft Defender Antivirus for Windows 10 using the settings catalog.

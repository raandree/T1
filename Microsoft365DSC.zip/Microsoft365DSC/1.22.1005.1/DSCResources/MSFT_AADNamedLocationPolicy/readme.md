# AADNamedLocationPolicy

## Description

This resource configures the Azure AD Named Location Policies in Azure Active Directory

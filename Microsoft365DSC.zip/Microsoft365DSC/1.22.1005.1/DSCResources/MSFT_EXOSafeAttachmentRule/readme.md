# EXOSafeAttachmentRule

## Description

This resource configures an Safe Attachment Rule in Exchange Online.

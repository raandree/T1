
# IntuneDeviceConfigurationPolicyMacOS

## Description

This resource configures an Intune device configuration profile for an MacOS Device.

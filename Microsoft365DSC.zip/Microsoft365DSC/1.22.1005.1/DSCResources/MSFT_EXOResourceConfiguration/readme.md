# EXOResourceConfiguration

## Description

Modify the resource Configuration policy in your cloud-based organization.

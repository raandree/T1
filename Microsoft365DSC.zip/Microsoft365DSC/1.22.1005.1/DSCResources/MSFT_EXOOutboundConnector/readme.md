# EXOOutboundConnector

## Description

Create a new Inbound connector in your cloud-based organization.

# EXOCASMailboxPlan

## Description

This resource configures Client Access services (CAS) mailbox plans
in cloud-based organizations.

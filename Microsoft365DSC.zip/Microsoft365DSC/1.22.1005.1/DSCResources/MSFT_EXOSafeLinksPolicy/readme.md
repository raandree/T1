# EXOSafeLinksPolicy

## Description

This resource configures the settings of the SafeLinks policies
in your cloud-based organization.

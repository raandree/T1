# EXOAntiPhishRule

## Description

This resource configures an Anti-Phish Rule in Exchange Online.
Reference: https://docs.microsoft.com/en-us/powershell/module/exchange/advanced-threat-protection/new-antiphishRule?view=exchange-ps

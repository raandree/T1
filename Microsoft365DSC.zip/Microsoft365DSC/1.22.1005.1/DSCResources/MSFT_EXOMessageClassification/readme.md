# EXOMessageClassification

## Description

Create a new Message Classification policy in your cloud-based organization.

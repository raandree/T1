
# SPOSharingSettings

## Description

This resource allows users to configure and monitor the sharing settings for
your SPO tenant sharing settings

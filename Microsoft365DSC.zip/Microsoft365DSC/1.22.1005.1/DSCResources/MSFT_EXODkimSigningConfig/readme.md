# EXODkimSigningConfig

## Description

This resource configures the DomainKeys Identified Mail (DKIM) signing policy
settings for domains in a cloud-based organization.

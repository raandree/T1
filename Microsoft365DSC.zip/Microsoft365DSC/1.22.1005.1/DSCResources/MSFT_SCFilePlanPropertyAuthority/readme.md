# SCFilePlanPropertyAuthority

## Description

This resource configures an authority entry for Security and
Compliance File Plans.

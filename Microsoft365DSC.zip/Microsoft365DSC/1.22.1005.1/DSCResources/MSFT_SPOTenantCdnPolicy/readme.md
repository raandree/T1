# SPOTenantCdnPolicy

## Description

This resource configures Content Delivery Network policies
for SharePoint Online.

* Not supported in GCC High

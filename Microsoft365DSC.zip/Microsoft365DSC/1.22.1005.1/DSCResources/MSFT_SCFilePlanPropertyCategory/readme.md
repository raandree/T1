# SCFilePlanPropertyCategory

## Description

This resource configures a category entry for Security and
Compliance File Plans.

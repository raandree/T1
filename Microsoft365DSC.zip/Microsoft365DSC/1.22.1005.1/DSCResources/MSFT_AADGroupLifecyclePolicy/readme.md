# AADGroupLifecyclePolicy

## Description

This resource configures an Azure Active Directory Group Lifecycle Policy (e.g. Expiration).

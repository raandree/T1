# EXOAddressBookPolicy

## Description

This resource configures Address Book Policies in Exchange Online.

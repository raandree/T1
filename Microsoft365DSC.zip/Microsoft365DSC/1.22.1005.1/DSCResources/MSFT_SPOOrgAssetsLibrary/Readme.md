# SPOOrgAssetsLibrary

## Description

This resource configures an SharePoint Online Org site assets library.

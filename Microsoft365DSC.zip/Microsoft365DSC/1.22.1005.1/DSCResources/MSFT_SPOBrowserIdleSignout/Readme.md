# SPOBrowserIdleSignout

## Description

This resource configures an SharePoint Online Idle session sign-out policy.

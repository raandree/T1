# SCCaseHoldPolicy

## Description

This resource configures a eDiscovery Case Policy
in Security and Compliance Center.

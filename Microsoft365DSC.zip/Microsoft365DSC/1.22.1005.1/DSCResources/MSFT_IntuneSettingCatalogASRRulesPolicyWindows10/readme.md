
# IntuneSettingCatalogASRRulesPolicyWindows10

## Description

This resource configures a Intune Endpoint Protection Attack Surface Reduction rules policy for a Windows 10 Device.
This resource returns ASR rules created using settings catalog settings.


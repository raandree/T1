
# IntuneWifiConfigurationPolicyMacOS

## Description

This resource configures an Intune Wifi Configuration Policy for MacOS Device.

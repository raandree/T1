
# IntuneDeviceConfigurationPolicyAndroidDeviceOwner

## Description

This resource configures the settings of Android WorkProfile Device policies
in your cloud-based organization.

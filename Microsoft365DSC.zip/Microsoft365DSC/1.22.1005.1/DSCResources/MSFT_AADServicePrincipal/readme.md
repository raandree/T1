# AADServicePrincipal

## Description

This resource configures an Azure Active Directory ServicePrincipal.

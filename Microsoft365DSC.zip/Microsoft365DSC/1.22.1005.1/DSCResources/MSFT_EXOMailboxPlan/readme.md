# EXOMailboxPlan

## Description

Use this resource to modify the settings of mailbox plans in the cloud-based service.

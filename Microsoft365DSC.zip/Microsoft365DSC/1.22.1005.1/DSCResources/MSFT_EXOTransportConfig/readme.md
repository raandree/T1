# EXOTransportConfig

## Description

This resource configures the Exchange Online transport
settings.

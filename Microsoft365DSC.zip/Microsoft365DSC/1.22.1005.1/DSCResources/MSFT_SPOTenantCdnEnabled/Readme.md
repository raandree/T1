# SPOTenantCdnEnabled

## Description

This resource enables / disables SharePoint online CDN

* Not supported in GCC High

# EXOAvailabilityAddressSpace

## Description

Create a new AvailabilityAddressSpace in your cloud-based organization.

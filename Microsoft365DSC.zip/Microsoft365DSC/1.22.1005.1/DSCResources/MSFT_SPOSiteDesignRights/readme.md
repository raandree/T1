# SPOSiteDesignRights

## Description

This resource configures rights on Site Designs.

# EXOPerimeterConfiguration

## Description

Modify the perimeter Configuration policy in your cloud-based organization.

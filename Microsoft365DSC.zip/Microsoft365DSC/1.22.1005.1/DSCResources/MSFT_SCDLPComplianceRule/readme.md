# SCDLPComplianceRule

## Description

This resource configures a Data Loss Prevention Compliance
Rule in Security and Compliance Center.

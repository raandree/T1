
# SPOSiteAuditSettings

## Description

Set Audit settings for a site.

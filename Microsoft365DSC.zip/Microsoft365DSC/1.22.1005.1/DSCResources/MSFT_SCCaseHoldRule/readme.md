# SCCaseHoldRule

## Description

This resource configures an eDiscovery Case Hold Rule
in Security and Compliance.

# SPOSiteDesign

## Description

This resource configures Site Designs.

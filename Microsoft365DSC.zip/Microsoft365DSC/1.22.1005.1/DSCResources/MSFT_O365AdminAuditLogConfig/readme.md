# O365AdminAuditLogConfig

## Description

This resource configures Security and Compliance Center Admin Audit Log.

# SCAutoSensitivityLabelRule

## Description

This resource configures a Auto Sensitivity Label
Rule in Security and Compliance Center.

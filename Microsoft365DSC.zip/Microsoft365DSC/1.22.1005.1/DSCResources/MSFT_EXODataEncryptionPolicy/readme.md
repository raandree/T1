# EXODataEncryptionPolicy

## Description

Create a new Data Encryption policy in your cloud-based organization.

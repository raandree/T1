# AADRoleDefinition

## Description

This resource configures an Azure Active Directory role definition.
To configure custom roles you require an Azure AD Premium P1 license.
The account used to configure role definitions based on this resource needs either to be a
"Global Administrator" or a "Privileged role administrator".

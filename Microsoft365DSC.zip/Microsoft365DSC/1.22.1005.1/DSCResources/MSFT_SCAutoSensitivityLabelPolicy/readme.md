# SCAutoSensitivityLabelPolicy

## Description

This resource configures a Auto Sensitivity label policy in Security and Compliance.

# EXOCASMailboxSettings

## Description

This resource configures CAS mailbox settings.

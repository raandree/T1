# SCRetentionCompliancePolicy

## Description

This resource configures a Retention Compliance Policy in Security and Compliance.

# PPTenantSettingsIsolationSettings

## Description

This resource configures the Tenant Isolation settings for a Power Platform Tenant.

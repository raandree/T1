# AAD Tenant Details

## Description

This resource configures the Azure AD Tenant Details

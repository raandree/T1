# SPOSearchResultSource

## Description

This resource allows users to create and monitor SharePoint Online Search
Result Sources.

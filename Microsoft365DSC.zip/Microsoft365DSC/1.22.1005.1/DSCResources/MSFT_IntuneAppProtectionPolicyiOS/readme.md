
# IntuneAppProtectionPolicyiOS

## Description

This resource configures an Intune app protection policy for an iOS Device.

# AADSecurityDefaults

## Description

This resource configures the Security Defaults in Azure Active Directory.

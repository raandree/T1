# EXOQuarantinePolicy

## Description

Create or modify a EXOQuarantinePolicy in your cloud-based organization.

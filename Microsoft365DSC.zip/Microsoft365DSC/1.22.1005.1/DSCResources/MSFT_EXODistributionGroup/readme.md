# EXODistributionGroup

## Description

This resource configures Exchange Online distribution groups.

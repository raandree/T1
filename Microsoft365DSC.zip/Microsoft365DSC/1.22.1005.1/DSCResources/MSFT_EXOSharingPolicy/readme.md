# EXOSharingPolicy

## Description

This resource configures Sharing Policies in Exchange Online.

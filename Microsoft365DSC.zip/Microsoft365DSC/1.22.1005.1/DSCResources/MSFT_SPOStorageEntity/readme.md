# SPOStorageEntity

## Description

This resource configures Storage Entity for SharePoint Online.

# EXOAuthenticationPolicyAssignment

## Description

This resource assigns Exchange Online Authentication Policies to users.

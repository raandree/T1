# EXOAcceptedDomain

## Description

This resource configures the Accepted Email Domains in Exchange Online.

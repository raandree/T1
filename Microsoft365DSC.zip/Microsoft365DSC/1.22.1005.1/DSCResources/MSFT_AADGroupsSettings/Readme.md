# AADGroupsNamingPolicy

## Description

This resource configures an Azure Active Directory Groups Settings.

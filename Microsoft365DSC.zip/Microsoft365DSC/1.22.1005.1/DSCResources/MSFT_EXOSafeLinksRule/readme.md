# EXOSafeLinksRule

## Description

This resource configures an SafeLinks Rule in Exchange Online.

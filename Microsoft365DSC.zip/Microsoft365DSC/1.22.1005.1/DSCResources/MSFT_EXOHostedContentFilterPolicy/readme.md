# EXOHostedContentFilterPolicy

## Description

This resource configures the settings of connection filter policies
in your cloud-based organization.

# SCAuditConfigurationPolicy

## Description

This resource configures an Audit ConfigurationPolicy
in Security and Compliance Center.

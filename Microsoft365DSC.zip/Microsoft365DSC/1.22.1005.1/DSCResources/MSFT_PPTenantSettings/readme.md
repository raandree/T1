# PPTenantSettings

## Description

This resource configures a Power Platform Tenant.

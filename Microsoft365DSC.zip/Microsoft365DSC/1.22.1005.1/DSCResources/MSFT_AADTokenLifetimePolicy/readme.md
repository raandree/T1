# AADTokenLifetimePolicy

## Description

This resource configures the Azure AD Token Lifetime Policies

# EXOHostedOutboundSpamFilterPolicy

## Description

This resource configures the settings of the outbound spam filter policy
in your cloud-based organization.

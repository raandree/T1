# EXOOnPremisesOrganization

## Description

This resource configures On-Premises Organization in Exchange Online.

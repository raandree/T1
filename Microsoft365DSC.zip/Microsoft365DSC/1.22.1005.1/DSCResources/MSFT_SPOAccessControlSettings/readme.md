
# SPO Access Control Settings

## Description

This resource allows users to configure and monitor the access control settings for
your SPO tenant sharing settings.

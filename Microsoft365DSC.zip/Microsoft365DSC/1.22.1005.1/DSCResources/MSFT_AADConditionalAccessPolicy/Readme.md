# AADConditionalAccessPolicy

## Description

This resource configures an Azure Active Directory Conditional Access Policy.

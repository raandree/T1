# EXOOfflineAddressBook

## Description

This resource configures Offline Address Books in Exchange Online.

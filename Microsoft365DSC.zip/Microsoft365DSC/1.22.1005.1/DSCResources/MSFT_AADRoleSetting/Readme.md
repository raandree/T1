# AADRoleSetting

## Description

This resource configure existing Azure roles. All UI parameters can be configured using this resource like:
- Notifications
- require approval / ticket / justification / MFA

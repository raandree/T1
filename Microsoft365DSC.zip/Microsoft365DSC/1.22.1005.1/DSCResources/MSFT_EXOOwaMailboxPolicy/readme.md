# EXOOwaMailboxPolicy

## Description

This resource configures OWA Mailbox Policies in Exchange Online.

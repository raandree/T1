
# IntuneDeviceCompliancePolicyiOs

## Description

This resource configures the Intune compliance policies for iOs devices.

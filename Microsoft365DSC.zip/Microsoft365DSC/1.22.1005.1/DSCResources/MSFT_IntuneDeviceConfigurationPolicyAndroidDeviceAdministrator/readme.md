
# IntuneDeviceConfigurationPolicyAndroidDeviceAdministrator

## Description

This resource configures the settings of Android Device Administrator device restriction policy in your cloud-based organization.
